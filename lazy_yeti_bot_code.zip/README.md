# Lazy Yeti Bot
Telegram bot for FII/DII sectoral data, elite stocks, and OG stock filtering.